#!/usr/bin/env python3
"""
Test the FSM client with the correct endpoints
"""

import os
import sys

# Add the current directory to the path so we can import our modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from zoho_fsm_client import ZohoFSMClient

def test_fsm_client():
    """Test the FSM client"""
    print("🧪 Testing FSM Client")
    print("=" * 40)
    
    # Set environment variables for testing
    os.environ['ZOHO_CLIENT_ID'] = "1000.3W1DWDWE6VK331JVHDE4R6UCXR59QZ"
    os.environ['ZOHO_CLIENT_SECRET'] = "d1facfc63fe9e7f30a038a33b4f12f6c359dd37464"
    os.environ['ZOHO_REFRESH_TOKEN'] = "1000.46b406330c7bc61a2b5398b3f758a54f.bd5b0487f535c43f2c9cd436c2bb5f3b"
    os.environ['ZOHO_ORG_ID'] = "test_org"  # We'll get this from the API response
    
    try:
        # Initialize the client
        print("1. Initializing FSM client...")
        client = ZohoFSMClient("test_org")
        print("✅ FSM client initialized successfully")
        
        # Test getting work orders
        print("\n2. Testing work orders retrieval...")
        workorders = client.get_workorders(limit=3)
        print(f"✅ Retrieved {len(workorders)} work orders")
        
        if workorders:
            print(f"   First work order: {workorders[0].get('Name', 'N/A')}")
            print(f"   Status: {workorders[0].get('Status', 'N/A')}")
        
        # Test getting appointments
        print("\n3. Testing appointments retrieval...")
        appointments = client.get_appointments(limit=3)
        print(f"✅ Retrieved {len(appointments)} appointments")
        
        if appointments:
            print(f"   First appointment: {appointments[0].get('Name', 'N/A')}")
        
        print("\n🎉 FSM client test completed successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

if __name__ == "__main__":
    test_fsm_client() 